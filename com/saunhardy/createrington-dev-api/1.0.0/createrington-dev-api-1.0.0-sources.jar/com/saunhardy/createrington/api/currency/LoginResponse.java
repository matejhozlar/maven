package com.saunhardy.createrington.api.currency;

public record LoginResponse(
    String token
) {}
