package com.saunhardy.createrington.api;

public final class Endpoints {

    private Endpoints() {}

    // Currency
    public static final String CURRENCY_LOGIN = "/api/currency/login";
    public static final String CURRENCY_BALANCE = "/api/currency/balance";
    public static final String CURRENCY_PAY = "/api/currency/pay";
    public static final String CURRENCY_DEPOSIT = "/api/currency/deposit";
    public static final String CURRENCY_WITHDRAW = "/api/currency/withdraw";
    public static final String CURRENCY_TOP = "/api/currency/top";
    public static final String CURRENCY_DAILY = "/api/currency/daily";
    public static final String CURRENCY_HISTORY = "/api/currency/history";
    public static final String CURRENCY_LOTTERY_START = "/api/currency/lottery/start";
    public static final String CURRENCY_LOTTERY_JOIN = "/api/currency/lottery/join";

    // Presence
    public static final String PRESENCE = "/api/presence";
    public static final String PRESENCE_HEARTBEAT = "/api/presence/heartbeat";

    // Trains
    public static final String TRAINS_CRASH = "/api/trains/crash";

}
