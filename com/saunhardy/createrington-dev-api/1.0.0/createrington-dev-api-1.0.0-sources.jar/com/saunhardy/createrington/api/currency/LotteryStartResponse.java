package com.saunhardy.createrington.api.currency;

public record LotteryStartResponse(
    boolean success,
    String message,
    double entryAmount,
    String endsAt
) {}
