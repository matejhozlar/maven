package com.saunhardy.createrington.api.currency;

import com.google.gson.annotations.SerializedName;

public record PayResponse(
    boolean success,
    @SerializedName("new_sender_balance")
    double newSenderBalance
) {}
