package com.saunhardy.createrington.api.currency;

import java.util.List;

public record HistoryResponse(
    List<Transaction> transactions,
    int page,
    boolean hasMore
) {}
