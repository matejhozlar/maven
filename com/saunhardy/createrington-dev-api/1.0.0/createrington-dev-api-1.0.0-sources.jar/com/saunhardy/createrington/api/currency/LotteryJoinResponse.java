package com.saunhardy.createrington.api.currency;

public record LotteryJoinResponse(
    boolean success,
    String message,
    double entryAmount,
    double totalPot,
    int participantCount
) {}
