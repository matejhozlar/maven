package com.saunhardy.createrington.api.currency;

public record TopEntry(
    String name,
    double balance
) {}
