package com.saunhardy.createrington.api.currency;

public record BalanceResponse(
    double balance
) {}
