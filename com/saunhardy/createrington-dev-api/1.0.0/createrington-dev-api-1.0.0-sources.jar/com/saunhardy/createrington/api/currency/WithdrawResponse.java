package com.saunhardy.createrington.api.currency;

import com.google.gson.annotations.SerializedName;

public record WithdrawResponse(
    boolean success,
    double withdrawn,
    @SerializedName("new_balance")
    double newBalance,
    double denomination,
    int count
) {}
