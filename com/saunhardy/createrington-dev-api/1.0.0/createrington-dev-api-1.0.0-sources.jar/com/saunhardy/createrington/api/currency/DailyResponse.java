package com.saunhardy.createrington.api.currency;

public record DailyResponse(
    String message
) {}
