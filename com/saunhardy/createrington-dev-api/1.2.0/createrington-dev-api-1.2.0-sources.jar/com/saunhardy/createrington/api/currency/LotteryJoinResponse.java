package com.saunhardy.createrington.api.currency;

/**
 * Wire format: ApiResponse<LotteryJoinResponse>. This record describes the inner
 * `data` payload only -- the surrounding success/message/playerMessage
 * fields live on ApiResponse.
 */
public record LotteryJoinResponse(
    double entryAmount,
    double totalPot,
    int participantCount
) {}
