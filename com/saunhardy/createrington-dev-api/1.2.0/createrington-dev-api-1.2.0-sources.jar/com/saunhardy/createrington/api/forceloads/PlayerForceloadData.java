package com.saunhardy.createrington.api.forceloads;

import java.util.List;

public record PlayerForceloadData(
    String uuid,
    List<ChunkData> chunks
) {}
