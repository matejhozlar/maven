package com.saunhardy.createrington.api.currency;

/**
 * Wire format: ApiResponse<LotteryStartResponse>. This record describes the inner
 * `data` payload only -- the surrounding success/message/playerMessage
 * fields live on ApiResponse.
 */
public record LotteryStartResponse(
    double entryAmount,
    String endsAt
) {}
