package com.saunhardy.createrington.api.forceloads;

import java.util.List;

public record PartyForceloadData(
    String partyId,
    String partyName,
    int memberCount,
    boolean optedIn,
    List<PartyMemberData> members,
    List<ChunkData> chunks
) {}
