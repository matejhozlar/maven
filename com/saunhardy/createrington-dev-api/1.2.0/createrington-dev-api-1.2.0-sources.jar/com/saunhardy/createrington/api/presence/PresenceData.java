package com.saunhardy.createrington.api.presence;

public record PresenceData(
    String minecraftUsername,
    String uuid,
    String state,
    int serverId,
    String receivedAt
) {}
