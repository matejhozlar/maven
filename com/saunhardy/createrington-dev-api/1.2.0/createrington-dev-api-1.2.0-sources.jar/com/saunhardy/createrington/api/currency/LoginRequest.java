package com.saunhardy.createrington.api.currency;

public record LoginRequest(
    String uuid,
    String name
) {}
