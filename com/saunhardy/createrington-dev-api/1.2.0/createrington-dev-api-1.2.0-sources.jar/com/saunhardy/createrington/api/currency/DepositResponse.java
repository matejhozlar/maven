package com.saunhardy.createrington.api.currency;

import com.google.gson.annotations.SerializedName;

/**
 * Wire format: ApiResponse<DepositResponse>. This record describes the inner
 * `data` payload only -- the surrounding success/message/playerMessage
 * fields live on ApiResponse.
 */
public record DepositResponse(
    @SerializedName("new_balance")
    double newBalance
) {}
