package com.saunhardy.createrington.api.presence;

import com.saunhardy.createrington.api.Nullable;
import java.util.List;

public record HeartbeatRequest(
    List<HeartbeatPlayer> players,
    @Nullable Integer serverId,
    @Nullable Long timestamp
) {}
