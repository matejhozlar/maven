package com.saunhardy.createrington.api.presence;

public record HeartbeatData(
    int serverId,
    int playersReported,
    String receivedAt
) {}
