package com.saunhardy.createrington.api.currency;

import com.saunhardy.createrington.api.Nullable;

public record PayRequest(
    String toUuid,
    double amount,
    @Nullable String fromUuid
) {}
