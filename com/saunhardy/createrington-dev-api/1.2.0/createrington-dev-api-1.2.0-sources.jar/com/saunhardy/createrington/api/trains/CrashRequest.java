package com.saunhardy.createrington.api.trains;

import com.saunhardy.createrington.api.Nullable;
import java.util.List;

public record CrashRequest(
    String trainId,
    String trainName,
    @Nullable Double speed,
    @Nullable Integer carriageCount,
    @Nullable Position position,
    @Nullable String dimension,
    @Nullable Long timestamp,
    @Nullable String owner,
    @Nullable String driverUuid,
    @Nullable List<CrashPassenger> passengers,
    @Nullable BackwardsDriver backwardsDriver
) {}
