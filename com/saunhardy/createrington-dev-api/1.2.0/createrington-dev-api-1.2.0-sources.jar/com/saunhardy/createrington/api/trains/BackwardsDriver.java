package com.saunhardy.createrington.api.trains;

import com.saunhardy.createrington.api.Nullable;

public record BackwardsDriver(
    String uuid,
    @Nullable String name
) {}
