package com.saunhardy.createrington.api.currency;

import com.saunhardy.createrington.api.Nullable;

public record Transaction(
    int id,
    String amount,
    String balanceBefore,
    String balanceAfter,
    String transactionType,
    @Nullable String description,
    String createdAt
) {}
