package com.saunhardy.createrington.api.currency;

import com.saunhardy.createrington.api.Nullable;

public record DepositRequest(
    double amount,
    @Nullable String reason
) {}
