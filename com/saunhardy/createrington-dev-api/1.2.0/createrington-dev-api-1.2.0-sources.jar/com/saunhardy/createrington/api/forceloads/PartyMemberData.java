package com.saunhardy.createrington.api.forceloads;

public record PartyMemberData(
    String uuid
) {}
