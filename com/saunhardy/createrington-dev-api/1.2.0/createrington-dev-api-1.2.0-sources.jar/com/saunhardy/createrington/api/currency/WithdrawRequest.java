package com.saunhardy.createrington.api.currency;

public record WithdrawRequest(
    double denomination,
    int count
) {}
