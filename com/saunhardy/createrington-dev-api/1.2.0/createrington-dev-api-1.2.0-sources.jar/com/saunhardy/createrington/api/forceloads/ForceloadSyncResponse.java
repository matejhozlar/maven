package com.saunhardy.createrington.api.forceloads;

public record ForceloadSyncResponse(
    boolean success
) {}
