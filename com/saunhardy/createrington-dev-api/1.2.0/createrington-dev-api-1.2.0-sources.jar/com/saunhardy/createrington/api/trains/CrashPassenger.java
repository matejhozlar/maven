package com.saunhardy.createrington.api.trains;

import com.saunhardy.createrington.api.Nullable;

public record CrashPassenger(
    String uuid,
    @Nullable String name,
    boolean isDriver
) {}
