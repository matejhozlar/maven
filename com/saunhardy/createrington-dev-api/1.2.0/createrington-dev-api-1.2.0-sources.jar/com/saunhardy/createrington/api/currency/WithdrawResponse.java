package com.saunhardy.createrington.api.currency;

import com.google.gson.annotations.SerializedName;

/**
 * Wire format: ApiResponse<WithdrawResponse>. This record describes the inner
 * `data` payload only -- the surrounding success/message/playerMessage
 * fields live on ApiResponse.
 */
public record WithdrawResponse(
    double withdrawn,
    @SerializedName("new_balance")
    double newBalance,
    double denomination,
    int count
) {}
