package com.saunhardy.createrington.api.presence;

public record HeartbeatResponse(
    boolean success,
    String message,
    HeartbeatData data
) {}
