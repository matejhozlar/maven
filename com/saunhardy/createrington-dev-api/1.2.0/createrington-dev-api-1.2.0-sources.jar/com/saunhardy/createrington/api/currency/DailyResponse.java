package com.saunhardy.createrington.api.currency;

import com.saunhardy.createrington.api.Nullable;

/**
 * Wire format: ApiResponse<DailyResponse>. This record describes the inner
 * `data` payload only -- the surrounding success/message/playerMessage
 * fields live on ApiResponse.
 */
public record DailyResponse(
    @Nullable Double amount
) {}
