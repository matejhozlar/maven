package com.saunhardy.createrington.api.currency;

import com.google.gson.annotations.SerializedName;

/**
 * Wire format: ApiResponse<PayResponse>. This record describes the inner
 * `data` payload only -- the surrounding success/message/playerMessage
 * fields live on ApiResponse.
 */
public record PayResponse(
    @SerializedName("new_sender_balance")
    double newSenderBalance
) {}
