package com.saunhardy.createrington.api.currency;

/**
 * Wire format: ApiResponse<BalanceResponse>. This record describes the inner
 * `data` payload only -- the surrounding success/message/playerMessage
 * fields live on ApiResponse.
 */
public record BalanceResponse(
    double balance
) {}
