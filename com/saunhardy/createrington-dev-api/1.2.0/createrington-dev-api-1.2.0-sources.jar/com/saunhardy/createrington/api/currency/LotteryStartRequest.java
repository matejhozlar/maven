package com.saunhardy.createrington.api.currency;

public record LotteryStartRequest(
    double amount
) {}
