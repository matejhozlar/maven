package com.saunhardy.createrington.api.currency;

public record LotteryJoinRequest(
    double amount
) {}
