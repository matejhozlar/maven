package com.saunhardy.createrington.api.presence;

public record HeartbeatPlayer(
    String uuid,
    String username
) {}
