package com.saunhardy.createrington.api.trains;

public record CrashResponse(
    boolean success
) {}
