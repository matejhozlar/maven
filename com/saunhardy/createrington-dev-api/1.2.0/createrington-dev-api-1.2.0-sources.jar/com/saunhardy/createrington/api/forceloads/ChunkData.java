package com.saunhardy.createrington.api.forceloads;

public record ChunkData(
    String dimension,
    int x,
    int z,
    boolean active
) {}
