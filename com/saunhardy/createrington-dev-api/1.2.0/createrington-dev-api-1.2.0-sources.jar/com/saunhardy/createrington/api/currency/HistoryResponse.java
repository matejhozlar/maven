package com.saunhardy.createrington.api.currency;

import java.util.List;

/**
 * Wire format: ApiResponse<HistoryResponse>. This record describes the inner
 * `data` payload only -- the surrounding success/message/playerMessage
 * fields live on ApiResponse.
 */
public record HistoryResponse(
    List<Transaction> transactions,
    int page,
    boolean hasMore
) {}
