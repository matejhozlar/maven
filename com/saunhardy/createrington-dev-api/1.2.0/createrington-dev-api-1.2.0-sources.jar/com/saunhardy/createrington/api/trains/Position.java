package com.saunhardy.createrington.api.trains;

public record Position(
    double x,
    double y,
    double z
) {}
