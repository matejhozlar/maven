package com.saunhardy.createrington.api.presence;

public record Position(
    double x,
    double y,
    double z
) {}
