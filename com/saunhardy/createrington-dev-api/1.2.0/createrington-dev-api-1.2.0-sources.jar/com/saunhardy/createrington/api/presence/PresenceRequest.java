package com.saunhardy.createrington.api.presence;

import com.saunhardy.createrington.api.Nullable;

public record PresenceRequest(
    String minecraftUsername,
    String uuid,
    String state,
    @Nullable Long timestamp,
    @Nullable Integer serverId,
    @Nullable Position position,
    @Nullable String dimension
) {}
