package com.saunhardy.createrington.api;

import com.google.gson.annotations.SerializedName;

public record ApiResponse<T>(
    boolean success,
    String message,
    @Nullable @SerializedName("playerMessage") String playerMessage,
    @Nullable T data
) {
    public static <T> ApiResponse<T> ok(String message, T data) {
        return new ApiResponse<>(true, message, null, data);
    }

    public static <T> ApiResponse<T> ok(String message, String playerMessage, T data) {
        return new ApiResponse<>(true, message, playerMessage, data);
    }

    public static <T> ApiResponse<T> fail(String message) {
        return new ApiResponse<>(false, message, null, null);
    }

    public static <T> ApiResponse<T> fail(String message, String playerMessage) {
        return new ApiResponse<>(false, message, playerMessage, null);
    }
}
