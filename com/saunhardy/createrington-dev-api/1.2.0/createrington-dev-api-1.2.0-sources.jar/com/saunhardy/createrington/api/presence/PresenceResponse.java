package com.saunhardy.createrington.api.presence;

public record PresenceResponse(
    boolean success,
    String message,
    PresenceData data
) {}
