package com.saunhardy.createrington.api.forceloads;

import java.util.List;

public record ForceloadSyncRequest(
    int serverId,
    long timestamp,
    List<PlayerForceloadData> players,
    List<PartyForceloadData> parties
) {}
