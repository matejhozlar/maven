package com.saunhardy.createrington.api.parties;

public record PartySyncResponse(
    boolean success
) {}
