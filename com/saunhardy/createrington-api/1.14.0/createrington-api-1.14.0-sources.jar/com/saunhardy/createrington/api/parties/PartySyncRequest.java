package com.saunhardy.createrington.api.parties;

import java.util.List;

public record PartySyncRequest(
    int serverId,
    List<PartyData> parties
) {}
