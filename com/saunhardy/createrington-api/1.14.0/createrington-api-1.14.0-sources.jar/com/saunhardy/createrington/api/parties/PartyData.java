package com.saunhardy.createrington.api.parties;

import com.saunhardy.createrington.api.Nullable;
import java.util.List;

public record PartyData(
    String teamId,
    String name,
    String description,
    int color,
    boolean freeToJoin,
    List<PartyMemberData> members,
    List<String> allies,
    @Nullable String tagCode
) {}
