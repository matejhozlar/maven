package com.saunhardy.createrington.api.parties;

import com.saunhardy.createrington.api.Nullable;

public record PartyMemberData(
    String uuid,
    String rank,
    @Nullable Integer claims,
    @Nullable Integer forceloads
) {}
