package com.saunhardy.createrington.api.parties;

import java.util.List;

public record PartyClaimsRequest(
    int serverId,
    String hash,
    List<PartyClaimDimensionData> dimensions
) {}
