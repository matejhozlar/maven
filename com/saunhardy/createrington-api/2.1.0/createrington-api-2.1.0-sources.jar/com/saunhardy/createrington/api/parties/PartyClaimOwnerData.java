package com.saunhardy.createrington.api.parties;

import java.util.List;

public record PartyClaimOwnerData(
    String owner,
    List<List<Integer>> claims,
    List<List<Integer>> forceloads
) {}
