package com.saunhardy.createrington.api.parties;

public record PartyClaimsResponse(
    boolean success,
    int stored
) {}
