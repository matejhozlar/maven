package com.saunhardy.createrington.api.parties;

import java.util.List;

public record PartyClaimDimensionData(
    String dimension,
    List<PartyClaimOwnerData> owners
) {}
