package com.saunhardy.createrington.api.chunks;

public record ChunkSyncResponse(
    boolean success
) {}
