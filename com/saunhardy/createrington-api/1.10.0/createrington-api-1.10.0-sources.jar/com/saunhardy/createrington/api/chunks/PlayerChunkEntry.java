package com.saunhardy.createrington.api.chunks;

public record PlayerChunkEntry(
    String dimension,
    int x,
    int z,
    boolean forceloadable,
    boolean active
) {}
