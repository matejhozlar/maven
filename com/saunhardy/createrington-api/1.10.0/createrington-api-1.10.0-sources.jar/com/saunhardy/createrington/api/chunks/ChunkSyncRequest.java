package com.saunhardy.createrington.api.chunks;

import java.util.List;

public record ChunkSyncRequest(
    int serverId,
    long timestamp,
    List<PlayerChunkData> players
) {}
