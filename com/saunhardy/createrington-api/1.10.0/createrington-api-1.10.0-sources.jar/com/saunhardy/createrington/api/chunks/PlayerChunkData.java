package com.saunhardy.createrington.api.chunks;

import com.saunhardy.createrington.api.Nullable;
import java.util.List;

public record PlayerChunkData(
    String playerUuid,
    @Nullable String partyId,
    @Nullable String partyName,
    @Nullable List<String> partyMembers,
    @Nullable Boolean partyOptedIn,
    List<PlayerChunkEntry> chunks
) {}
