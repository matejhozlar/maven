package com.saunhardy.createrington.api.currency;

import com.saunhardy.createrington.api.Nullable;

public record WithdrawRequest(
    double denomination,
    int count,
    @Nullable String idempotencyKey
) {}
