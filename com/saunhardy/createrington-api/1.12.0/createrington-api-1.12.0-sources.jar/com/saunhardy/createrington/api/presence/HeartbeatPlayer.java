package com.saunhardy.createrington.api.presence;

import com.saunhardy.createrington.api.Nullable;

public record HeartbeatPlayer(
    String uuid,
    String minecraftUsername,
    @Nullable Integer playTimeTicks
) {}
