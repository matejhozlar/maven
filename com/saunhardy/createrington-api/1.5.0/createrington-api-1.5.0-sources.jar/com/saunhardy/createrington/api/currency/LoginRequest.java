package com.saunhardy.createrington.api.currency;

import com.saunhardy.createrington.api.Nullable;

public record LoginRequest(
    String uuid,
    @Nullable String name
) {}
