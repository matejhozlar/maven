package com.saunhardy.createrington.api.allies;

public record AlliedPartyData(
    String partyId,
    long alliedAt
) {}
