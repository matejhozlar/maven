package com.saunhardy.createrington.api.allies;

public record PendingQualifiedPlayerData(
    String uuid,
    long qualifiedAt
) {}
