package com.saunhardy.createrington.api.allies;

public record AllySyncResponse(
    boolean success
) {}
