package com.saunhardy.createrington.api.allies;

import java.util.List;

public record FakePlayerPartyData(
    String partyId,
    String ownerUuid,
    String ownerName,
    List<FakePlayerPartyMemberData> members
) {}
