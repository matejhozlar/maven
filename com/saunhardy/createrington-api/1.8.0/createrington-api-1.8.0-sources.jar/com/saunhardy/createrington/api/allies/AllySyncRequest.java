package com.saunhardy.createrington.api.allies;

import java.util.List;

public record AllySyncRequest(
    int serverId,
    long timestamp,
    FakePlayerPartyData fakePlayerParty,
    List<AlliedPartyData> allies,
    List<QualifiedPlayerData> qualified,
    List<PendingQualifiedPlayerData> pending
) {}
