package com.saunhardy.createrington.api.currency;

public record PayRequest(
    String toUuid,
    double amount
) {}
