package com.saunhardy.createrington.api.allies;

public record QualifiedPlayerData(
    String uuid,
    long qualifiedAt
) {}
