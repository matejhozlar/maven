package com.saunhardy.createrington.api.allies;

public record FakePlayerPartyMemberData(
    String uuid
) {}
